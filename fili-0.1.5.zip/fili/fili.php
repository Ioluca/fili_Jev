<?php
/**
 * Plugin Name:       Fili
 * Description:       Finds the internal links your site is missing and the posts that tell the same news twice. It proposes, it does not write: you approve every link, and one click undoes it.
 * Version:           0.1.5
 * Requires at least: 6.4
 * Requires PHP:      8.0
 * Author:            Luca Cazzaniga
 * License:           MIT
 * License URI:       https://opensource.org/licenses/MIT
 * Text Domain:       fili
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'FILI_VERSION', '0.1.5' );
define( 'FILI_DIR', plugin_dir_path( __FILE__ ) );
define( 'FILI_URL', plugin_dir_url( __FILE__ ) );

require_once FILI_DIR . 'includes/class-fili-db.php';
require_once FILI_DIR . 'includes/class-fili-lang.php';
require_once FILI_DIR . 'includes/class-fili-text.php';
require_once FILI_DIR . 'includes/class-fili-jev.php';
require_once FILI_DIR . 'includes/class-fili-engine.php';
require_once FILI_DIR . 'includes/class-fili-apply.php';
require_once FILI_DIR . 'includes/class-fili-queue.php';
require_once FILI_DIR . 'includes/class-fili-key.php';

register_activation_hook( __FILE__, array( 'Fili_DB', 'install' ) );
register_deactivation_hook( __FILE__, array( 'Fili_Queue', 'stop' ) );

add_action( 'init', function () {
	// The code speaks English; Italian and anything else come from languages/.
	load_plugin_textdomain( 'fili', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
} );
add_action( 'admin_init', array( 'Fili_DB', 'maybe_upgrade' ) );
add_action( 'fili_apply_batch', array( 'Fili_Queue', 'run' ) );

if ( is_admin() ) {
	require_once FILI_DIR . 'includes/class-fili-admin.php';
	Fili_Admin::boot();
}

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	require_once FILI_DIR . 'includes/class-fili-cli.php';
}

/**
 * Settings with their defaults. One place, so nothing reads an option by a bare string.
 *
 * @return array<string,mixed>
 */
function fili_settings(): array {
	$defaults = array(
		'route'          => 'typesafe',
		'language'       => 'it',
		'post_types'     => array( 'post' ),
		'threshold'      => 0.60,
		'max_per_post'   => 3,
		'parallel'       => 4, // questions in flight at once; 1 on a fragile shared host
		'batch_size'     => 5,  // links applied per wake-up
		'batch_minutes'  => 30, // minutes between wake-ups
		'monthly_budget' => 1.00,
		'themes'         => '',
		'read_only'      => 1, // while on, Fili can propose but has no way to touch a post
	);
	$saved = get_option( 'fili_settings', array() );
	return array_merge( $defaults, is_array( $saved ) ? $saved : array() );
}

/**
 * The API key. A constant in wp-config.php wins; otherwise the option, which is
 * stored with autoload off and never printed back in full.
 */
function fili_api_key(): string {
	if ( defined( 'FILI_API_KEY' ) && FILI_API_KEY ) {
		return (string) FILI_API_KEY;
	}
	return (string) get_option( 'fili_api_key', '' );
}
